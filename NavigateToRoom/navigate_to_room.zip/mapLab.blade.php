<!DOCTYPE html>
<html>
<head>
    <title>Map</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.8.0/dist/leaflet.css"/>
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.74.0/dist/L.Control.Locate.min.css"/>
    <style>
        body {
            margin: 0;
            padding: 0;
        }

        #lab-selection {
            position: absolute;
            top: 10px;
            left: 50px;
            background-color: white;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        #back-button {
            position: fixed;
            top: 120px;
            left: 10px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        #back-button:hover {
            background-color: #0056b3;
        }

        .custom-label {
            text-align: center;
            background-color: white;
            padding: 5px 10px;
            border-radius: 8px;
            border: 1px solid black;
            font-size: 14px;
            font-weight: bold;
            color: black;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            pointer-events: none;
        }
        .popup-image {
            width: 150px;
            height: auto;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div id="lab-selection">
        <label for="labSelect">Choose a lab:</label>
        <select id="labSelect">
            <option value="">Select a lab</option>
            <option value="lab1">Software Engineering Lab 1</option>
            <option value="lab2">Software Engineering Lab 2</option>
            <option value="lab3">Software System Lab</option>
            <option value="lab4">Network Lab</option>
        </select>
    </div>
    <div id="map" style="width: 100%; height: 100vh"></div>
    <button id="back-button" onclick="goBack()">Back</button>
</body>
</html>

<script src="https://unpkg.com/leaflet@1.8.0/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
<script src="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.74.0/dist/L.Control.Locate.min.js" charset="utf-8"></script>
<script>
    // Initialize map
    var map = L.map('map').setView([3.0000700927040866, 101.71098263712543], 11);

    L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
        attribution: "Map data &copy; <a href='https://www.openstreetmap.org/'>OpenStreetMap</a> contributors"
    }).addTo(map);

    // Lab locations
    var labs = {
        lab1: { name: "Software Engineering Lab 1", lat: 2.999700, lng: 101.710048, image:"selab.jpeg"},
        lab2: { name: "Software Engineering Lab 2", lat: 2.999705, lng: 101.710056, image:"selab.jpeg"},
        lab3: { name: "Software System Lab", lat: 2.999549, lng: 101.710064, image:"softwaresystem.jpg"},
        lab4: { name: "Network Lab", lat: 2.999431, lng: 101.710061, image:"networklab.jpeg"}
    };

    // Add markers for labs
    var labMarkers = {};
    for (var lab in labs) {
        labMarkers[lab] = L.marker([labs[lab].lat, labs[lab].lng])
            .bindPopup(labs[lab].name)
            .addTo(map);
    }

    // "You are here" label
    var currentPositionMarker = L.marker([3.0000700927040866, 101.71098263712543], {
        icon: L.divIcon({
            className: 'custom-label',
            html: '<div>You are here</div>',
            iconSize: [120, 20],
            iconAnchor: [60, 0]
        })
    }).addTo(map);

    // Moving marker
    var movingMarker = L.marker([3.0000700927040866, 101.71098263712543], {
        icon: L.icon({
            iconUrl: 'gps.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34]
        })
    }).addTo(map);

    // Route control reference (to remove it later if needed)
    var routeControl = null;

    // Event listener for dropdown
    document.getElementById('labSelect').addEventListener('change', function (event) {
        var selectedLab = event.target.value;

        if (!selectedLab) {
            alert("Please select a lab.");
            return;
        }

        var lab = labs[selectedLab];

        // Remove existing route if it exists
        if (routeControl) {
            map.removeControl(routeControl);
        }

        // Route control
        routeControl = L.Routing.control({
            waypoints: [
                L.latLng(movingMarker.getLatLng()),
                L.latLng(lab.lat, lab.lng)
            ],
            createMarker: function () { return null; }, // Prevents default markers
            routeWhileDragging: false
        }).on('routesfound', function (e) {
            var coordinates = e.routes[0].coordinates;
            var totalTime = e.routes[0].summary.totalTime; // Total travel time in seconds

            coordinates.forEach(function (coord, index) {
                setTimeout(() => {
                    movingMarker.setLatLng([coord.lat, coord.lng]);

                    // Calculate remaining time
                    var remainingTime = Math.round((totalTime - (totalTime / coordinates.length) * index) / 60);

                    if (index === coordinates.length - 1) {
                        window.alert("Destination Reached at " + lab.name);
                        movingMarker.bindPopup(`<strong>${lab.name}</strong><br><img src="${lab.image}" class="popup-image" alt="${lab.name}">`).openPopup();
                    } 
                }, 100 * index);
            });
        }).addTo(map);
    });

    // Locate control
    L.control.locate().addTo(map);

    // Back button function
    function goBack() {
        window.history.back();
    }
</script>
