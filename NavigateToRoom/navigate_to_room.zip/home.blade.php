@use('Illuminate\Support\Facades\Vite')
 
<!doctype html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=pin_drop" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Digital FSKTM Directory</title>
    <style>
        {!! Vite::content('resources/css/app.css') !!}
    </style>
    <script>
        {!! Vite::content('resources/js/app.js') !!}
    </script>
</head>
<body>
<header>
    <div class="header">
    <span  onclick="openNav()">&#9776; </span>
    <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="{{ url("/navigate") }}"><i class="bx bx-right-arrow">NAVIGATE TO ROOM</i></a>
        </div>
    <script>
    function openNav(){
        document.getElementById("mySidenav").style.width="250px";
    }
    function closeNav(){
        document.getElementById("mySidenav").style.width="0";
    }
    </script>
    <span class="header-title">Grid Falcon</span>
    </div>
</header>

<h1>DIGITAL FSKTM DIRECTORY</h1>
<button class="login" type="submit" name="submit">Login</button>
    <div class="search-container">
    <span class="pin-drop material-symbols-outlined">pin_drop</span>
        <input class="search-input" type="search" placeholder="Search for room..."></input>
</div>
    <h6>Where do you need to go?</h6>
    <section class="overlay"></section>
    <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1594.2847845644362!2d101.70970174095773!3d2.9994332471153475!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cdca83cf937cd3%3A0x89d9dd194ab060b3!2sFaculty%20of%20Computer%20Science%20and%20Information%20Technology%2C%20UPM!5e1!3m2!1sen!2smy!4v1736408705254!5m2!1sen!2smy" width="400" height="300" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        <button class="overlay-button">FACULTY MAP IMAGE</button></p>
</body>
</html>