<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital FSKTM Directory</title>
    <style>
        {!! Vite::content('resources/css/app.css') !!}
    </style>
    <script>
        {!! Vite::content('resources/js/app.js') !!}
    </script>
</head>
<body>
    <header>
    <div class="header">
    <span  onclick="openNav()">&#9776; </span>
    <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="{{ url("/") }}"><i class="bx bx-right-arrow">BACK TO HOME</i></a>
        </div>
        <script>
    function openNav(){
        document.getElementById("mySidenav").style.width="250px";
    }
    function closeNav(){
        document.getElementById("mySidenav").style.width="0";
    }
    </script>
         <span class="header-title">Grid Falcon</span>
</div>
    </header>
    <main class="main-content">
        <h1>DIGITAL FSKTM DIRECTORY</h1>
        <div class="directory">
            <div class="item">
                <img src="lab.jpg" alt="Lab">
                <p>LAB</p>
                <a href="{{ url("/mapLab") }}" class="button">START NAVIGATION</a>
            </div>
            <div class="item">
                <img src="toilet.jpg" alt="Toilet">
                <p>TOILET</p>
                <a href="{{ url("/mapToilet") }}" class="button">START NAVIGATION</a>
            </div>
            <div class="item">
                <img src="lecture_hall.jpg" alt="Lecture Hall">
                <p>LECTURE HALL</p>
                <a href="{{ url("/maplecturehall") }}" class="button">START NAVIGATION</a>
            </div>
            <div class="item">
                <img src="classroom.jpg" alt="Putra Future Classroom">
                <p>PUTRA FUTURE CLASSROOM</p>
                <a href="{{ url("/mapPFC") }}" class="button">START NAVIGATION</a>
            </div>
            <div class="item">
                <img src="office.jpeg" alt="Office">
                <p>OFFICE</p>
                <a href="{{ url("/mapOffice") }}" class="button">START NAVIGATION</a>
            </div>
        </div>
    </main>
</body>
</html>

