<!DOCTYPE html>
<html>
    <head>
        <title>Map Live Route</title>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.8.0/dist/leaflet.css" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.74.0/dist/L.Control.Locate.min.css" />
        <style>
            body {
                margin: 0;
                padding: 0;
            }

            #back-button {
                position: fixed;
                top: 120px;
                left: 10px;
                padding: 10px 20px;
                font-size: 16px;
                background-color: #007BFF;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
                z-index: 1000;
                opacity: 1;
            }

            #back-button:hover {
                background-color: #0056b3;
            }

            .custom-label {
                text-align: center;
                background-color: white;
                padding: 5px 10px;
                border-radius: 8px;
                border: 1px solid black;
                font-size: 14px;
                font-weight: bold;
                color: black;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
                max-width: 150px;
                white-space: nowrap;
                pointer-events: none;
            }

            .leaflet-popup-content img {
                max-width: 100%;
                height: auto;
            }
        </style>
    </head>
    <body>
        <div id="map" style="width: 100%; height: 100vh"></div>
        <button id="back-button" onclick="goBack()">Back</button>

        <script src="https://unpkg.com/leaflet@1.8.0/dist/leaflet.js"></script>
        <script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
        <script>
            // Initialize the map
            var map = L.map('map').setView([3.0000700927040866, 101.71098263712543], 15);

            // Add tile layer
            L.tileLayer('https://{s}.tile.osm.org/{z}/{x}/{y}.png', { 
                attribution: "Map data &copy; <a href='https://www.openstreetmap.org/'>OpenStreetMap</a> contributors" 
            }).addTo(map);

            // Add static markers for start and destination
            var startMarker = L.marker([3.0000700927040866, 101.71098263712543], {
                icon: L.divIcon({
                    className: 'custom-label',
                    html: '<div>You are here</div>',
                    iconSize: [120, 20],
                    iconAnchor: [60, 0]
                })
            }).addTo(map);

            var destinationMarker = L.marker([2.999735,101.710394]).addTo(map).bindPopup("<p>This is the Putra Future Classroom</p> <img src='pfc.jpeg'/>");
            
            var greenIcon = L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowSize: [41, 41]
            });

            // Add a moving marker
            var movingMarker = L.marker([3.0000700927040866, 101.71098263712543],{icon: greenIcon}).addTo(map);

            // Routing control to calculate route
            L.Routing.control({
                waypoints: [
                    L.latLng(3.0000700927040866, 101.71098263712543),
                    L.latLng(2.999735,101.710394)
                ],
                createMarker: function () { return null; } // Prevents extra markers
            }).on('routesfound', function (e) {
                // Extract the route coordinates
                var coordinates = e.routes[0].coordinates;

                // Move the marker along the route
                coordinates.forEach(function (coord, index) {
                    setTimeout(() => {
                        movingMarker.setLatLng([coord.lat, coord.lng]);
                        
                        // Check if the marker reaches the final destination
                        if (index === coordinates.length - 1) {
                            destinationMarker.openPopup(); // Show the pop-up
                            alert("Destination Reached!");
                        }
                    }, 100 * index); // Adjust speed by modifying delay
                });
            }).addTo(map);

            // Back button functionality
            function goBack() {
                window.history.back();
            }
        </script>
    </body>
</html>
